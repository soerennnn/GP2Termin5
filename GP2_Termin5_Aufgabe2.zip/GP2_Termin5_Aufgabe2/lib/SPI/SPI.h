#ifndef SPI_H_
#define SPI_H_

#include <stdint.h>
#include <avr/io.h>

  
        
#define CS      PB0     // Pin 53    CS          
#define SCK     PB1     // Pin 52    SCL 
#define MOSI    PB2     // Pin 51   SDO 
#define MISO    PB3     // Pin 50 SDA (SDI)   


void SPI_MasterInit(void);
void SPI_MasterTransmit(char data);
uint8_t SPI_MasterReceive(void);

#endif 