#define F_CPU 16000000

#define MISO PB3// connected to SDI on LIS3DH
#define MOSI PB2// connected to SDO on LIS3DH
#define SCK PB1  // connected to SCK on LIS3DH
#define CS PB0   // connected to CS on LIS3DH

#include <avr/io.h>
#include <util/delay.h>
#include <UART.h>
#include <SPI.h>











int main(void) {
    // UART Initialisierung mit Baudrate 9600 UBRR0 = 103
    UART0_INIT(103);

    // SPI Initialisierung
    SPI_MasterInit();

    uint8_t datax;

    while(1) {

        // Byte über UART empfangen
        datax = UART0_receive();
        
        // Byte über SPI senden
        SPI_MasterTransmit(datax);
        datax = SPDR;

        // Empfangenes Byte über UART senden
        UART0_send(datax);

        _delay_ms(500); // Verzögerung
    }
}