/*******************************************************************************
 ***                                                                         ***
 *** filename:   UART.cpp                                                    ***
 ***                                                                         ***
 *** project:    Grundpraktikum II                                           ***
 ***                                                                         ***
 *** created on: 2020-03-20                                                  ***
 ***                                                                         ***
 *** created by: Lukas Kroll                                                 ***
 ***             FH Dortmund                                                 ***
 ***             Labore fuer Informationstechnik                             ***
 ***             lukas.kroll@fh-dortmund.de                                  ***
 ***                                                                         ***
 ***                                                                         ***
 *** version:    1.0.0                                                       ***
 ***                                                                         ***
 *** updated on:                                                             ***
 ***                                                                         ***
 *** info:       UART Bibliothek for use with Atmel Atmega 2560 only         ***
 ***             Atmega 2560 has four UART interfaces                        ***
 ***             UART0 is accessable via USB connection                      ***
 ***                                                                         ***
 ***                                                                         ***
 ******************************************************************************/

#include <avr/io.h>
#include <stdlib.h>
#include <string.h>
#include "UART.h"


/************************************************************************/
/*				           UART0 FUNCTIONS	                            */
/************************************************************************/

void UART0_INIT(uint16_t ubrr)
{
	UBRR0H = (uint8_t)(ubrr>>8);				//UBRR0H Baud rate register high Byte 
	UBRR0L = (uint8_t)(ubrr);					//UBRR0L Baud rate register low Byte
	UCSR0B |= 	(1<<RXEN0)  | (1<<TXEN0); 						//RXEN0 Receiver enable, TXEN0 Transmitter enable
	UCSR0C |= (1<<UCSZ00) | (1<<UCSZ01) ;		//Payload 8bit, 1 Stopbit, kein Parit‰tsbit
}

unsigned char UART0_receive(void)
{

	while(!(UCSR0A & (1<<RXC0)));				//Wurden Daten Empfangen?
	return UDR0;								//R¸ckgabe Inhalt USART0 Sende- und Empfangsregister

}

void UART0_send(unsigned char data)
{

	while(!(UCSR0A & (1<<UDRE0)));				//ist UDR0 leer?
	UDR0 = data;								//schreiben in: USART0 Sende- und Empfangsregister

}

uint8_t UART0_msgRCV()
{
	return (UCSR0A & (1<<RXC0));				// R¸ckgabewert = 1, wenn sich eine Empfangene Nachricht im Empfangsspeicher befindet
}

void UART0_send_ascii(uint32_t toprint)
{
	uint8_t len = 0;
	char str[255];
	unsigned char c;
	
	ltoa(toprint, str, 10);                    // Wandeln des Integerwertes in einen String
	
	len = strlen(str);                        // Auslesen der L‰nge des Strings
	
	for (uint8_t i=0;i<=len-1;i++)            // Ausgabe der einzelnen Chars ( einzeln gedruckt for-schleife mit stringl‰nge)
	{
		c = str[i];
		UART0_send(c);
	}
}

/************************************************************************/
/*				           UART1 FUNCTIONS	                            */
/************************************************************************/

void UART1_INIT(uint16_t ubrr)
{
	UBRR1H = (uint8_t)(ubrr>>8);				//UBRR1H Baud rate register high Byte
	UBRR1L = (uint8_t)(ubrr);					//UBRR1L Baud rate register low Byte
	UCSR1B |= (1<<RXEN1)  | (1<<TXEN1);			//RXEN1 Receiver enable, TXEN1 Transmitter enable
	UCSR1C |= (1<<UCSZ10) | (1<<UCSZ11) ;		//Payload 8bit, 1 Stopbit, kein Parit‰tsbit
}

unsigned char UART1_receive(void)
{

	while(!(UCSR1A & (1<<RXC1)));				//Wurden Daten Empfangen
	return UDR1;								//R¸ckgabe Inhalt USART1 Sende- und Empfangsregiste

}

void UART1_send(unsigned char data)
{

	while(!(UCSR1A & (1<<UDRE1)));				//ist UDR1 leer?
	UDR1 = data;								//schreiben in: USART1 Sende- und Empfangsregiste

}

uint8_t UART1_msgRCV()
{
	return (UCSR1A & (1<<RXC1));				// R¸ckgabewert = 1, wenn sich eine Empfangen Nachricht im Empfangsspeicher befindet
}

/************************************************************************/
/*				           UART2 FUNCTIONS	                            */
/************************************************************************/

void UART2_INIT(uint16_t ubrr)
{
	UBRR2H = (uint8_t)(ubrr>>8);				//UBRR1H Baud rate register high Byte
	UBRR2L = (uint8_t)(ubrr);					//UBRR1L Baud rate register low Byte
	UCSR2B |= (1<<RXEN2)  | (1<<TXEN2);			//RXEN1 Receiver enable, TXEN1 Transmitter enable
	UCSR2C |= (1<<UCSZ20) | (1<<UCSZ21) ;		//Payload 8bit, 1 Stopbit, kein Parit‰tsbit
}

unsigned char UART2_receive(void)
{

	while(!(UCSR2A & (1<<RXC2)));				//Wurden Daten Empfangen
	return UDR2;								//R¸ckgabe Inhalt USART2 Sende- und Empfangsregiste

}

void UART2_send(unsigned char data)
{

	while(!(UCSR1A & (1<<UDRE1)));				//ist UDR2 leer?
	UDR2 = data;								//schreiben in: USART2 Sende- und Empfangsregiste

}

uint8_t UART2_msgRCV()
{
	return (UCSR2A & (1<<RXC2));				// R¸ckgabewert = 1, wenn sich eine Empfangen Nachricht im Empfangsspeicher befindet
}


/************************************************************************/
/*				           UART3 FUNCTIONS	                            */
/************************************************************************/

void UART3_INIT(uint16_t ubrr)
{
	UBRR3H = (uint8_t)(ubrr>>8);				//UBRR1H Baud rate register high Byte
	UBRR3L = (uint8_t)(ubrr);					//UBRR1L Baud rate register low Byte
	UCSR3B |= (1<<RXEN3)  | (1<<TXEN3);			//RXEN1 Receiver enable, TXEN1 Transmitter enable
	UCSR3C |= (1<<UCSZ30) | (1<<UCSZ31) ;		//Payload 8bit, 1 Stopbit, kein Parit‰tsbit
}

unsigned char UART3_receive(void)
{

	while(!(UCSR3A & (1<<RXC3)));				//Wurden Daten Empfangen
	return UDR3;								//R¸ckgabe Inhalt USART3 Sende- und Empfangsregiste

}

void UART3_send(unsigned char data)
{

	while(!(UCSR3A & (1<<UDRE3)));				//ist UDR3 leer?
	UDR3 = data;								//schreiben in: USART3 Sende- und Empfangsregiste

}

uint8_t UART3_msgRCV()
{
	return (UCSR3A & (1<<RXC3));				//R¸ckgabewert = 1, wenn sich eine Empfangen Nachricht im Empfangsspeicher befindet
}