#define F_CPU 16000000

#define MISO PB3// connected to SDI on LIS3DH
#define MOSI PB2// connected to SDO on LIS3DH
#define SCK PB1  // connected to SCK on LIS3DH
#define CS PB0   // connected to CS on LIS3DH

#include <avr/io.h>
#include <util/delay.h>
#include <UART.h>
#include <SPI.h>
#include <LIS3DH.h>



int main(void) {
    // UART Initialisierung mit Baudrate 9600 UBRR0 = 103
    UART0_INIT(103);

    // SPI Initialisierung
    SPI_MasterInit();

    // CS Pin als Ausgang definieren
    DDRB |= (1<<CS);


    uint8_t WhoAmI;

    while(1) {

            UART0_send('S');  // Sendet 'S' für Start

        // Chip Select auf Low setzen um Kommunikation zu starten
        PORTB &= ~(1<<CS);

        // Adresse des Who Am I Registers mit Readbit übertragen
        SPI_MasterTransmit(0x8F); // 0x0F mit gesetztem Readbit (0x80)

        _delay_ms(10);
        // Dummy-Byte senden um den Wert zu erhalten
        SPI_MasterTransmit(0x00);

        _delay_ms(10);
  

        // Empfangenen Wert aus SPDR Register lesen
        WhoAmI = SPDR;

        // Chip Select auf high setzen, um Kommunikation zu beenden
        PORTB |= (1<<CS);

        // Empfangenen Wert per UART senden
        UART0_send(WhoAmI);
            UART0_send('E');  // Sendet 'E' für Ende

    }
}


