/*
 * LIS3DH.h
 *
 * Created: 14.05.2018 13:50:02
 *  Author: Kroll
 */ 


#ifndef LIS3DH_H_
#define LIS3DH_H_

char SPI_LIS3DH_INIT(void);
int16_t LIS3DH_getX(void);
int16_t LIS3DH_getY(void);
int16_t LIS3DH_getZ(void);
/************************************************************************/
/*				           LIS3DH REG DEF					            */
/************************************************************************/

#define WHO_AM_I	0x0F

#define OUT_X_L		0x28
#define OUT_X_H		0x29
#define OUT_Y_L		0x2A
#define OUT_Y_H		0x2B
#define OUT_Z_L		0x2C
#define OUT_Z_H		0x2D

#define CTRL_REG1	0x20
#define CTRL_REG2	0x21
#define CTRL_REG3	0x22
#define CTRL_REG4	0x23
#define CTRL_REG5	0x24
#define CTRL_REG6	0x25

/* CTRL_REG1 Parameter */
#define Xen			0x00
#define Yen			0x01
#define Zen			0x02
#define LPen		0x03

#endif /* LIS3DH_H_ */